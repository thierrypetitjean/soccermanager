package com.example.soccermanager.managers

import android.util.Log
import com.example.soccermanager.models.FootballClub
import com.example.soccermanager.models.Match
import com.example.soccermanager.ScoreComparator
import java.util.*
import kotlin.collections.ArrayList

class PoulManager(private val numberOfClubs: Int) : LeagueManager {

    val league: ArrayList<FootballClub>
    val matches: ArrayList<Match>
    var hasBall = 0
    var scoredGoal = 0
    var averageScoreChange = 3
    var homeGoals = 0
    var awayGoals = 0
    val situations: ArrayList<String>
    var playedGames = 0

    init {
        league = ArrayList()
        matches = ArrayList()
        situations = ArrayList()
    }

    fun addTeam(team: String, location: String, teamStrength: Int): String {
        if (league.size == numberOfClubs) {
            return "Can't add more clubs to league"
        }

        val club = FootballClub()
        club.name = team

        if (league.contains(club)) {
            return "This club is already in the league"
        }

        club.teamStrenght = teamStrength
        club.location = location
        league.add(club)

        return club.name + "added successfully"
    }

    private fun deleteTeam(team: String): String {

        for (club in league) {
            if (club.name.equals(team)) {
                league.remove(club)
                return "Club " + club.name + " removed"

            }
        }
        return "No such club in league"
    }

    private fun displayStatistics(clubName: String): String {

        var result = ""
        for (club in league) {
            if (club.name!!.equals(clubName)) {
                result += "Club " + club.name + " matches won: " + club.winCount + "\n"
                result += "Club " + club.name + " matches lost: " + club.defeatCount + "\n"
                result += "Club " + club.name + " matches draw: " + club.drawCount + "\n"
                result += "Club " + club.name + " scored goals: " + club.scoredGoalsCount + "\n"
                result += "Club " + club.name + " recieved goals: " + club.receivedGoalsCount + "\n"
                result += "Club " + club.name + " points: " + club.points + "\n"
                result += "Club " + club.name + " matches played: " + club.matchesPlayed + "\n"
            }
        }
        if (result != "") {
            Log.d("playing", "display statitics = " + result)
            return result
        }
        return "No such club in league"
    }

    fun getFinalResults(): ArrayList<FootballClub> {

        Collections.sort(league, ScoreComparator())

        var result = ""
        for (club in league) {
            result += "Club: " + club.name + " Points: " + club.points + " goal difference: " + (club.scoredGoalsCount - club.receivedGoalsCount) + " goals scored = " + club.scoredGoalsCount + " matches played = " + club.matchesPlayed + "\n"
        }

        Log.d("playing", "display league \n" + result)

        return league
    }

    fun playGamesInPoul(teamA: FootballClub, teamB: FootballClub, teamC: FootballClub, teamD: FootballClub) : Match?
    {
        var matchResult: Match? = null
        if(league.size == 4) {
            if (playedGames == 0) {
                playedGames++
                matchResult = playMatch(teamA, teamB, getRandomSituationCount())
                return matchResult
            } else if (playedGames == 1) {
                matchResult = playMatch(teamC, teamD, getRandomSituationCount())
                playedGames++
                return matchResult
            } else if (playedGames == 2) {
                matchResult = playMatch(teamC, teamA, getRandomSituationCount())
                playedGames++
                return matchResult
            } else if (playedGames == 3) {
                matchResult = playMatch(teamD, teamB, getRandomSituationCount())
                playedGames++
                return matchResult
            } else if (playedGames == 4) {
                matchResult = playMatch(teamD, teamA, getRandomSituationCount())
                playedGames++
                return matchResult
            } else if (playedGames == 5) {
                matchResult = playMatch(teamB, teamC, getRandomSituationCount())
                playedGames++
                return matchResult
            } else if (playedGames == 6) {
                Log.d("playing", "Poul finished")
            }
        }
        else
        {
            Log.d("playing", "Poul size is not 4")
        }

        return matchResult
    }

    fun resetPoul()
    {
        for(team in league)
        {
            team.scoredGoalsCount = 0
            team.matchesPlayed = 0
            team.drawCount = 0
            team.winCount = 0
            team.points = 0
            team.defeatCount = 0
            team.setRecievedGoalsCount(0)
        }

        playedGames = 0
    }

    fun playMatch(home: FootballClub, away: FootballClub, situationCount: Int) : Match
    {
        situations.clear()
        situations.add(starMatch(home, away))

        var index = 0
        while(index < situationCount) {

            situations.add(howHasBall(home, away))
            situations.add(tryToScore(home, away))
            situations.add(showIfScored(home, away))
            situations.add(showCurrentScore(home, away))
            index++
        }
        situations.add(endMatch(home, away))
        val match = submitScore(home, away, situations)

        return match
    }

    fun addExtraTeamSpirit(club: FootballClub): String {
        if (club.teamStrenght < 100) {
            club.teamStrenght = club.teamStrenght + 10
            return "winning poul team: " + club.name + " has team strenght upgraded to " + club.teamStrenght
        }

        return "winning poul team: " + club.name + " already has max team strength " + club.teamStrenght
    }

    fun decreaseTeamSpirit(club: FootballClub): String {
        if (club.teamStrenght > 0) {
            club.teamStrenght = club.teamStrenght - 10
            return "losing poul team: " + club.name + " has team strenght downgraded to " + club.teamStrenght
        }

        return "losing poul team: " + club.name + " already has a minimum team strength of " + club.teamStrenght
    }

    private fun starMatch(home: FootballClub, away: FootballClub) : String
    {
        return "match started: " + home.name + " vs " + away.name + " in " + home.location
    }

    private fun endMatch(home: FootballClub, away: FootballClub) : String
    {
        return "match ended: " + home.name + " vs " + away.name + " with " + homeGoals + " / " + awayGoals
    }

    private fun howHasBall(home: FootballClub, away: FootballClub) : String
    {
        hasBall = Random().nextInt(2)

        if (hasBall == 0) {
            return "team " + home.name + " has the ball"
        } else {
            return "team " + away.name + " has the ball"
        }
    }

    private fun tryToScore(home: FootballClub, away: FootballClub) : String
    {
        if (hasBall == 0) {
            return "team " + home.name + " tries to score"
        } else {
            return "team " + away.name + " tries to score"
        }
    }

    private fun showIfScored(home: FootballClub, away: FootballClub) : String
    {

        if (home.teamStrenght > away.teamStrenght) {
            averageScoreChange = 2
        }

        scoredGoal = Random().nextInt(averageScoreChange)
        if (scoredGoal == 1) {
            if (hasBall == 0) {
                homeGoals++
                return "team " + home.name + " scored a goal "
            } else {
                awayGoals++
                return "team " + away.name + " scored a goal "
            }
        }
        else {
            if (hasBall == 0) {
                return "team " + home.name + " missed a shot "
            } else {
                return "team " + away.name + " missed a shot "
            }
        }
    }

    private fun showCurrentScore(home: FootballClub, away: FootballClub) : String
    {
        return "team " + home.name + " vs " + away.name + " " + homeGoals + " / " + awayGoals

    }

    private fun submitScore(home: FootballClub, away: FootballClub, situations: ArrayList<String>) : Match
    {
        val match = Match()
        match.teamA = home
        match.teamB = away

        match.teamAScore = awayGoals
        match.teamBScore = homeGoals
        match.matchSituations = situations
        matches.add(match)
        home.scoredGoalsCount = home.scoredGoalsCount + homeGoals
        away.scoredGoalsCount = away.scoredGoalsCount + awayGoals
        home.setRecievedGoalsCount(home.receivedGoalsCount + awayGoals)
        away.setRecievedGoalsCount(away.receivedGoalsCount + homeGoals)
        home.matchesPlayed = home.matchesPlayed + 1
        away.matchesPlayed = away.matchesPlayed + 1

        Log.d("home", "home = " + home.name + " played matches = " + home.matchesPlayed)
        Log.d("home", "away = " + away.name + " played matches = " + away.matchesPlayed)

        if (homeGoals > awayGoals) {
            home.points = home.points + 3
            home.winCount = home.winCount + 1
            away.defeatCount = away.defeatCount + 1
        } else if (homeGoals < awayGoals) {
            away.points = away.points + 3
            away.winCount = away.winCount + 1
            home.defeatCount = home.defeatCount + 1
        } else {
            home.points = home.points + 1
            away.points = away.points + 1
            home.drawCount = home.drawCount + 1
            away.drawCount = away.drawCount + 1
        }

        homeGoals = 0
        awayGoals = 0

        return match
    }

    fun getRandomSituationCount() : Int
    {
        return Random().nextInt(10)
    }

}