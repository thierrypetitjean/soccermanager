package com.example.soccermanager.models

class FootballClub : SportsClub() {

    var winCount: Int = 0
    var drawCount: Int = 0
    var defeatCount: Int = 0
    var scoredGoalsCount: Int = 0
    var receivedGoalsCount: Int = 0
        private set
    var points: Int = 0
    var matchesPlayed: Int = 0
    var teamStrenght: Int = 0

    fun setRecievedGoalsCount(i: Int) {
        receivedGoalsCount = i
    }

}
