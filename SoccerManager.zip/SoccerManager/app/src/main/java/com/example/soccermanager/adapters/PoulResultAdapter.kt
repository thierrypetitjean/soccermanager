package com.example.soccermanager.adapters

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.soccermanager.R
import com.example.soccermanager.models.FootballClub
import kotlinx.android.synthetic.main.tournament_row.view.*

class TableAdapter(val items: ArrayList<FootballClub>, val context: Context) : RecyclerView.Adapter<ViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ViewHolder(
            LayoutInflater.from(context).inflate(
                R.layout.tournament_row,
                parent,
                false
            )
        )
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {

        holder.tvClubName?.text = items.get(position).name
        holder.tvPoints?.text = items.get(position).points.toString()
        holder.tvGoalDif?.text =
            (items.get(position).scoredGoalsCount - items.get(position).receivedGoalsCount).toString()
        holder.tvMatchesPlayed?.text = items.get(position).matchesPlayed.toString()
        holder.tvGoalsReceived?.text = items.get(position).receivedGoalsCount.toString()
        holder.tvScoredGoals?.text = items.get(position).scoredGoalsCount.toString()

    }

    override fun getItemCount(): Int {
        return items.size
    }

}

class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
    val tvClubName = view.txtClubName
    val tvPoints = view.txtPoints
    val tvGoalDif = view.txtGoalDif
    val tvMatchesPlayed = view.txtMatchesPlayed
    val tvScoredGoals = view.txtScoredGoals
    val tvGoalsReceived = view.txtGoalsReceived
}