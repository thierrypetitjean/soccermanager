package com.example.soccermanager.managers

interface LeagueManager {
}