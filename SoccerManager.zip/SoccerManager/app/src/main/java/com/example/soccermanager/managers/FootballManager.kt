package com.example.soccermanager.managers

object FootballManager {

    /**
     * @param args the command line arguments
     */
    @JvmStatic
    fun main(args: Array<String>) {
        PoulManager(4)
    }

}
