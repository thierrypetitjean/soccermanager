package com.example.soccermanager

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.TableLayout
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.soccermanager.adapters.SituationAdapter
import com.example.soccermanager.adapters.TableAdapter
import com.example.soccermanager.managers.PoulManager
import com.example.soccermanager.models.FootballClub
import com.example.soccermanager.models.Match

class MainActivity : AppCompatActivity() {

    private lateinit var btnPlayGame: Button

    private lateinit var txtInfo1: TextView
    private lateinit var txtInfo2: TextView

    private lateinit var rvSituations: RecyclerView

    private lateinit var tlHeader: TableLayout

    private lateinit var fManager: PoulManager
    private lateinit var teamA: FootballClub
    private lateinit var teamB: FootballClub
    private lateinit var teamC: FootballClub
    private lateinit var teamD: FootballClub

    var isPoulFinished = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        txtInfo1 = findViewById(R.id.txtInfo)
        txtInfo2 = findViewById(R.id.txtInfo2)
        btnPlayGame = findViewById(R.id.btnPlayGame)
        tlHeader = findViewById(R.id.tlHeader)
        tlHeader.visibility = View.INVISIBLE
        txtInfo1.visibility = View.INVISIBLE
        txtInfo2.visibility = View.INVISIBLE
        rvSituations = findViewById(R.id.rvSituations)
        rvSituations.layoutManager = LinearLayoutManager(this)
        mockPoul()

        btnPlayGame.setOnClickListener {
            val match = fManager.playGamesInPoul(teamA, teamB, teamC, teamD)
            if (!isPoulFinished) {
                if (match != null) {
                    showMatchResults(match)
                } else {
                    Log.d("playing", "poul finished")
                    tlHeader.visibility = View.VISIBLE
                    txtInfo1.visibility = View.VISIBLE
                    txtInfo2.visibility = View.VISIBLE
                    val scoreList = fManager.getFinalResults()
                    rvSituations.adapter = TableAdapter(scoreList, this)
                    isPoulFinished = true
                    btnPlayGame.text = getString(R.string.replay_poul)

                    //Add extra teamStrenght to the winner of the poul. (max 100 teamStrenght).
                    val infoText1 = fManager.addExtraTeamSpirit(fManager.league.get(0))
                    txtInfo1.text = infoText1

                    //Decrease teamSrenght to the loser of the poul. (min 0 temStrenght).
                    val infoText2 = fManager.decreaseTeamSpirit(fManager.league.get(3))
                    txtInfo2.text = infoText2
                }
            } else {
                tlHeader.visibility = View.INVISIBLE
                txtInfo1.visibility = View.INVISIBLE
                txtInfo2.visibility = View.INVISIBLE
                rvSituations.adapter = null
                fManager.resetPoul()
                isPoulFinished = false
                btnPlayGame.text = getString(R.string.play_poul)
            }
        }

    }

    fun mockPoul() {
        fManager = PoulManager(4)
        fManager.addTeam("Ajax", "Amsterdam", 100)
        fManager.addTeam("ADO", "Den Haag", 50)
        fManager.addTeam("PSV", "Eindhoven", 70)
        fManager.addTeam("AZ", "Alkmaar", 60)

        teamA = fManager.league.get(0)
        teamB = fManager.league.get(1)
        teamC = fManager.league.get(2)
        teamD = fManager.league.get(3)
    }

    fun showMatchResults(matchResult: Match) {
        rvSituations.adapter = SituationAdapter(matchResult.matchSituations, this)
    }

}
