package com.example.soccermanager.models

import com.example.soccermanager.models.FootballClub
import kotlin.collections.ArrayList

class Match {

    var teamA: FootballClub? = null
    var teamB: FootballClub? = null
    var teamAScore: Int = 0
    var teamBScore: Int = 0
    var matchSituations: ArrayList<String> = arrayListOf()

}
