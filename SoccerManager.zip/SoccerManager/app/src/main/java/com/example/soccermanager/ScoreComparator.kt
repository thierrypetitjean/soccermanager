package com.example.soccermanager

import com.example.soccermanager.models.FootballClub
import java.util.Comparator

class ScoreComparator : Comparator<FootballClub> {

    override fun compare(t: FootballClub, t1: FootballClub): Int {

        if (t.points > t1.points) {
            return -1
        }
        else if (t.points < t1.points) {
            return 1
        }
        else {
            val goalDif = t.scoredGoalsCount - t.receivedGoalsCount
            val goalDif1 = t1.scoredGoalsCount - t1.receivedGoalsCount
            if (goalDif > goalDif1) {
               return -1
            }
            else if (goalDif < goalDif1) {
                return 1
            }
            else if(t.receivedGoalsCount < t1.receivedGoalsCount)
            {
                return -1
            }
            else{
                return 1
            }
        }

    }
}
