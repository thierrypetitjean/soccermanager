package com.example.soccermanager.models

abstract class SportsClub {

    var name: String? = null
    var location: String? = null

    override fun equals(o: Any?): Boolean {
        return this.name == (o as SportsClub).name
    }

}